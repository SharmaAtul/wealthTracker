<?php
	include ("include/constants.php");
	include("header.php");
?>

<div id="L2_root">
<table border="0" align="center" cellpadding="20" cellspacing="0">
<tr>
<td  width="300px"></td>
<td  width="400px" align="center">
<table  class="shoppingcart" cellspacing="0" cellpadding="5" border="0">
    <tr>
        <td nowrap colspan="2" align="center" height="70"><h2><strong>Thank You</strong></h2></td>
    </tr>
    <tr>
        <td nowrap colspan="2" align="center"><p>&nbsp;</p>
          <p>Thank you for sending us your Product selection. <br />You will receive a confirmation email shortly with the details of this request.</p>
          <p>&nbsp;</p></td>
    </tr>
    <tr>
        <td align="center" valign="middle" colspan="2" height="50px">
        <p><a href="index.php" style=" font-size:16px"><strong>Return to Product Wheel</strong></a></p></td>
    </tr>
	</table>
</td>
<td  width="300px"></td>
</tr>
</table>
</div>
<?php include("footer.php"); ?>